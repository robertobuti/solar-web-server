//*************************************************************************************************
// main application management 
// check data from inverter's
// send data to pVoutput web site
// see comlynx.pdf for detail on Danfoss protocol comunication (downloadadle from danfoss web site)
//
// see comlynx.pdf for detail on Danfoss protocol comunication (downloadadle from danfoss web site)
//
// written by Roberto Buti, email : roberto@robertobuti.it
// rev. 1.0 8/04/2011
//
//*************************************************************************************************
#include "routine.h"
#include "TCPIP Stack/Tick.h"

char MyString[45];	// string buffer for dato to TCPclient
extern unsigned char rxbuffer[40];		// Uart2 buffer Rx 
extern unsigned char receivedchar;		// received char
extern char GenericTCPExampleState;
void UTCToDate(unsigned char format,char String[]);
void DanfossMNG(void);
char inverter_nr;		// numero dell'inverter in esame
char status_query;		// stato delle query in corso
char sendToServer;		// used to send data on external web server

// CHANGE HERE THE INVERTER id**********************************************************************************************************************
#define RS485addressH_1	0xd5	// RS485 inverter address My first one
#define RS485addressL_1	0x3c	// RS485 inverter address
#define RS485addressH_2	0xda	// RS485 inverter address My second one
#define RS485addressL_2	0x6a	// RS485 inverter address
#define RS485addressH_3	0xd5	// RS485 inverter address Daniela one
#define RS485addressL_3	0x4b	// RS485 inverter address
unsigned long total_power[3];		// total power up today
unsigned long today_power[3];		// total power of today
unsigned long instant_power[3];		// instant power 



static unsigned char total[10]={0xc8,0x04,0xd0,0x01,0x02,0x87,0x00,0x00,0x00,0x00};	// string to ask total energy production
static unsigned char instant[10]={0xc8,0x04,0xd0,0x01,0x01,0x87,0x00,0x00,0x00,0x00};	// string to ask instant energy production
static unsigned char today[10]={0xc8,0x04,0xd0,0x01,0x04,0x87,0x00,0x00,0x00,0x00};	// string to ask total of today

static unsigned char dummydata[1]={0x00};


unsigned long timersend;		// used to send data each 15 minutes
unsigned long query_timeout;	// timeout response from inverter
unsigned long timerquery;		// used to ask data each 30 seconds

char zeronosend;	// do not send if value are 0



// ****************************************************************************************************
//
//Danfooss main loop 
// check and send data each 15 minute
//
//*****************************************************************************************************
void DanfossMNG()
{
char strbuffer[10];

// PING TO CAPTURE THE INVERTER ID**********************************************************************************************************************
// the ping is a goof method to discover the id of the target
//rxbuffer[3] and rxbuffer[4] are the inverter RS485 iD
//sendmsg(0xff,0xff,0,0x15,(unsigned int*)dummydata);			// broadcast ping
//while (1);
//

// size, type, msg
// menage receivd message and update all value
if (checkmessage())	// received a message ?
	{
	if (decodemsg(receivedchar));	// if the message is OK procede
		{
		if ((rxbuffer[3] == RS485addressH_1)&&(rxbuffer[4] == RS485addressL_1))	// the message is from inverter 1
			{
			switch (rxbuffer[13])	// type of received paramter
				{
				case 0x01:
					instant_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 4;
					break;
				case 0x02:
					total_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 6;
					break;
				case 0x04:
					today_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 8;
					break;
				default :
					break;
				}
			}
		if ((rxbuffer[3] == RS485addressH_2)&&(rxbuffer[4] == RS485addressL_2))	// the message is from inverter 2
			{
			switch (rxbuffer[13])	// type of received paramter
				{
				case 0x01:
					instant_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 4;
					break;
				case 0x02:
					total_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 6;
					break;
				case 0x04:
					today_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 8;
					break;
				default :
					break;
				}
			}
		if ((rxbuffer[3] == RS485addressH_3)&&(rxbuffer[4] == RS485addressL_3))	// the message is from inverter 3
			{
			switch (rxbuffer[13])	// type of received paramter
				{
				case 0x01:
					instant_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 4;
					break;
				case 0x02:
					total_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 6;
					break;
				case 0x04:
					today_power[(int)inverter_nr] = ((long)rxbuffer[18] << 24) + ((long)rxbuffer[17] << 16) + ((long)rxbuffer[16] << 8) + (long)rxbuffer[15];
//					status_query = 8;
					break;
				default :
					break;
				}
			}
		}
	receivedchar = 0;		// clear buffer pointer
	}


// data from inverter updated ever 30"
if((TickGet() - timerquery) > TICK_SECOND * 30)
	{
	timerquery = TickGet();		// save time now for nex timer
	status_query = 2;	// start the query cycle
	}


// seem the inverter need time from one message to a second one, so 
// the status_query doesn't change anymore aftermessage received but for timeout in any case.
// in this way work fine !!!
// check for timeout RX data from inverter
if ((status_query == 3)||(status_query == 5)||(status_query == 7))	// wait for data
	{
	if((TickGet() - query_timeout) > TICK_SECOND )		// timeout a 1 secondo
		status_query++;			// same state of received message
	}

// manage request to inverter
if (status_query)	// query active ?
	{
	// send the request
	switch (inverter_nr)
		{
		case 0:
			{
			switch (status_query)
				{
				case 2:	
					sendmsg(RS485addressH_1,RS485addressL_1,10,0x1,(unsigned char*)instant);	// request instant			
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 3;
					break;
				case 4:
					sendmsg(RS485addressH_1,RS485addressL_1,10,0x1,(unsigned char*)total);	// request total production		
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 5;
					break;
				case 6:
					sendmsg(RS485addressH_1,RS485addressL_1,10,0x1,(unsigned char*)today);	// request today total production			
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 7;
					break;
				default :
					break;
				}
			break;
			}
		case 1:
			{
			switch (status_query)
				{
				case 2:	
					sendmsg(RS485addressH_2,RS485addressL_2,10,0x1,(unsigned char*)instant);	// request instant			
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 3;
					break;
				case 4:
					sendmsg(RS485addressH_2,RS485addressL_2,10,0x1,(unsigned char*)total);	// request total production		
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 5;
					break;
				case 6:
					sendmsg(RS485addressH_2,RS485addressL_2,10,0x1,(unsigned char*)today);	// request today total production			
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 7;
					break;
				default :
					break;
				}
			break;
			}
		case 2:
			{
			switch (status_query)
				{
				case 2:	
					sendmsg(RS485addressH_3,RS485addressL_3,10,0x1,(unsigned char*)instant);	// request instant			
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 3;
					break;
				case 4:
					sendmsg(RS485addressH_3,RS485addressL_3,10,0x1,(unsigned char*)total);	// request total production		
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 5;
					break;
				case 6:
					sendmsg(RS485addressH_3,RS485addressL_3,10,0x1,(unsigned char*)today);	// request today total production			
					query_timeout = TickGet();		// save time now for RX timeout from inverter
					status_query = 7;
					break;
				default :
					break;
				}
		default :
			break;
			}
		}
	}


// cycle for next inverter
if ((status_query == 8))	// wait for latest data
	{
	inverter_nr ++;			// cycle for next inverter	
	if (inverter_nr >= 3)
		{
		status_query = 0;		// reset all
		inverter_nr = 0;
		}
	else
		status_query = 2;		
	}



// timer used to send data on pvoutput server each 15'
if((TickGet() - timersend) > TICK_MINUTE * 15)		// timeout a 15 minuti
	{
	timersend = TickGet();		// save time now for nex timer
	sendToServer = 1;			// enable machine to send data on server
	}

// reset flag to disable pvoutput data when value are 0
if ((instant_power[0] != 0) || (instant_power[1] != 0) || (instant_power[2] != 0))
	zeronosend = TRUE;		// enable value message to pvoutput



// menage data for TCP client
// id and key string managed directly in TCPclient.c
if ((sendToServer != 0) && (zeronosend != 0))	// request ??
	{
	switch (sendToServer)
		{
		case 1:	
			{
			UTCToDate(1,(char*)MyString);		// make the string with data
			strcat(MyString,"&v1=");			// energy value total of today, sum of 2 inverter 
			ultoa(today_power[0] + today_power[1],(BYTE*)strbuffer);
			strcat(MyString,strbuffer);
			strcat(MyString,"&v2=");			// instant value , sum of 2 inverter 
			ultoa(instant_power[0] + instant_power[1],(BYTE*)strbuffer);
			strcat(MyString,strbuffer);
			strcat(MyString,"\r\n");
			GenericTCPExampleState = 0;	// start the procedure to send on pvoutoput.org		
			sendToServer = 2;
			break;
			}
		case 2:	
			{
			if (GenericTCPExampleState == 4) 	// free ?
				sendToServer = 3;			
			break;
			}	
		case 3:
			{
			UTCToDate(1,(char*)MyString);		// make the string with data
			strcat(MyString,"&v1=");			// energy value
			ultoa(today_power[2],(BYTE*)strbuffer);
			strcat(MyString,strbuffer);
			strcat(MyString,"&v2=");			// instant value
			ultoa(instant_power[2],(BYTE*)strbuffer);
			strcat(MyString,strbuffer);
			strcat(MyString,"\r\n");
			GenericTCPExampleState = 0;	// start the procedure to send on pvoutoput.org		
			sendToServer = 4;
			break;
			}
		case 4:
			{
			if (GenericTCPExampleState == 4) 	// free ?
				{		
				sendToServer = 0;			
				if ((instant_power[0] == 0)&&(instant_power[1] == 0)&&(instant_power[2] == 0))
					zeronosend = 0;		// disable value message to pvoutput
				}
			break;
			}	
		default:
			break;
		}
	}
}
