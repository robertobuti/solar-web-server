unsigned int pppfcs16(unsigned int fcs,unsigned char* pByte, unsigned char length );
void sendmsg(unsigned char destinationH, unsigned char destinationL,unsigned char MSGsize,unsigned char MSGtype,unsigned char *MSG);
unsigned char decodemsg(unsigned char lenght);
char checkmessage(void);
