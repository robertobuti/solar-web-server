
 
/****************************************************************************
  SECTION 	Include
****************************************************************************/
/*
 * This macro uniquely defines this file as the main entry point.
 * There should only be one such definition in the entire project,
 * and this file must define the AppConfig variable as described below.
 */

#define THIS_IS_STACK_APPLICATION

// Include all headers for any enabled TCPIP Stack functions
#include "TCPIP Stack/TCPIP.h"

#if defined(STACK_USE_ZEROCONF_LINK_LOCAL)
#include "TCPIP Stack/ZeroconfLinkLocal.h"
#endif
#if defined(STACK_USE_ZEROCONF_MDNS_SD)
#include "TCPIP Stack/ZeroconfMulticastDNS.h"
#endif

#if defined( WF_CONSOLE )
#include "TCPIP Stack/WFConsole.h"
#include "IperfApp.h"
#endif 

#include "TCPIP Stack/Tick.h"

// Include functions specific to this stack application
#include "Main.h"

/****************************************************************************
  SECTION 	Declare
****************************************************************************/
// Declare AppConfig structure and some other supporting stack variables
APP_CONFIG AppConfig;
BYTE AN0String[8];

extern unsigned char 	GenericTCPExampleState;
extern unsigned long timersend;
unsigned char rxbuffer[40];		// Uart2 buffer Rx 
unsigned char receivedchar;		// received char
unsigned char rxflag;			// RX flag 
extern unsigned long startTime;
unsigned long timeoutconnection;	// timer to check the connection
extern char wstat;

//*******************************************************************************
//	DNS info
//*******************************************************************************
// CHANGE HERE THE DNS id**********************************************************************************************************************
ROM unsigned char DynDNS_HOST[30] = "robertobuti.no-ip.org";
ROM unsigned char DynDNS_USER[30] = "xxxxxxxxxxxxxxxxxx";
ROM unsigned char DynDNS_PASS[10] = "xxxxxxxxxxxxxxxxxx";



UINT8 ConnectionProfileID=0;	

int __C30_UART = 2;

int Conn_stat=0;	

// Private helper functions.
// These may or may not be present in all applications.

static void InitAppConfig(void);
static void InitializeBoard(void);

static void WF_Connect(void);


// C30 and C32 Exception Handlers
// If your code gets here, you either tried to read or write
// a NULL pointer, or your application overflowed the stack
// by having too many local variables or parameters declared.


#if defined(STACK_USE_UART)
  #define UART2PrintString    putrsUART
#else
  #define UART2PrintString(x)
#endif

/****************************************************************************
  SECTION 	ISR (Interrupt Service routines)
****************************************************************************/

void __attribute__((interrupt, auto_psv)) _U2RXInterrupt(void)
{
// Clear the interrupt flag so we don't keep entering this ISR
IFS1bits.U2RXIF = 0;
	if (receivedchar >= 40)
		receivedchar = 0;	// worst case
	if (U2STAbits.URXDA)
		{
		rxbuffer[receivedchar++]= U2RXREG;
		rxflag = TRUE;
		}
}


void __attribute__((interrupt, auto_psv)) _DefaultInterrupt(void)
{
  UART2PrintString( "!!! Default interrupt handler !!!\r\n" );
  while (1)
  {
	  Nop();
	  Nop();
	  Nop();
  }
}

void __attribute__((interrupt, auto_psv)) _OscillatorFail(void)
{
  UART2PrintString( "!!! Oscillator Fail interrupt handler !!!\r\n" );
  while (1)
  {
	  Nop();
	  Nop();
	  Nop();
  }
}
void __attribute__((interrupt, auto_psv)) _AddressError(void)
{
  UART2PrintString( "!!! Address Error interrupt handler !!!\r\n" );
  while (1)
  {
	  Nop();
	  Nop();
	  Nop();
  }
}
void __attribute__((interrupt, auto_psv)) _StackError(void)
{
  UART2PrintString( "!!! Stack Error interrupt handler !!!\r\n" );
  while (1)
  {
	  Nop();
	  Nop();
	  Nop();
  }
}
void __attribute__((interrupt, auto_psv)) _MathError(void)
{
  UART2PrintString( "!!! Math Error interrupt handler !!!\r\n" );
  while (1)
  {
	  Nop();
	  Nop();
	  Nop();
  }
}



/* used for WiFi assertions */
#ifdef WF_DEBUG
	#define WF_MODULE_NUMBER   WF_MODULE_MAIN_DEMO
#endif

/****************************************************************************
  MAIN APPLICATION ENTRY POINT
****************************************************************************/

int main(void)

{

	static DWORD dwLastIP = 0;


	// Initialize application specific hardware
	InitializeBoard();
	//UART2PrintString( "Starting...");
	
	// Initialize stack-related hardware components that may be 
	// required by the UART configuration routines
    TickInit();
	#if defined(STACK_USE_MPFS) || defined(STACK_USE_MPFS2)
	MPFSInit();
	#endif

	// Initialize Stack and application related NV variables into AppConfig.
	InitAppConfig();

	GenericTCPExampleState = 4;	//SM_DONE; // TCP client in wait mode
	timersend = TickGet();		// inizialize timer for data update, first data send in 15'
	timeoutconnection = TickGet();

	// Initialize core stack layers (MAC, ARP, TCP, UDP) and
	// application modules (HTTP, SNMP, etc.)
    StackInit();
	

	#if defined(WF_CS_TRIS)
		if (Conn_stat==0)	//picus
			WF_Connect();
    #endif

// init DNS client
	DDNSSetService(NO_IP_COM);
 	DDNSClient.Host.szROM = DynDNS_HOST;
	DDNSClient.ROMPointers.Host = 1;
 	DDNSClient.Username.szROM = DynDNS_USER;
	DDNSClient.ROMPointers.Username = 1;
 	DDNSClient.Password.szROM = DynDNS_PASS;
	DDNSClient.ROMPointers.Password = 1;
	DDNSForceUpdate();


	#if defined(STACK_USE_ZEROCONF_LINK_LOCAL)
    ZeroconfLLInitialize();
	#endif

	#if defined(STACK_USE_ZEROCONF_MDNS_SD)
	mDNSInitialize(MY_DEFAULT_HOST_NAME);
	mDNSServiceRegister(
		(const char *) "Solar panel monitor",		// base name of the service
		"_http._tcp.local",			    		// type of the service
		80,				                        // TCP or UDP port, at which this service is available
		((const BYTE *)"path=/index.htm"),		// TXT info
		1,								    	// auto rename the service when if needed
		NULL,							    	// no callback function
		NULL							    	// no application context
		);

    mDNSMulticastFilterRegister();			
	#endif


	
	
/****************************************************************************
  COOPERATIVE MULTITASKING LOOP
****************************************************************************/
    while(1)
    {	

        // This task performs normal stack task including checking
        // for incoming packet, type of packet and calling
        // appropriate stack entity to process it.
		#if defined(WF_CS_TRIS)
			if (Conn_stat==0)
				WF_Connect();
		#endif

		StackTask();
		
		// This tasks invokes each of the core stack application tasks
        StackApplications();

        #if defined(STACK_USE_ZEROCONF_LINK_LOCAL)
		ZeroconfLLProcess();
        #endif

        #if defined(STACK_USE_ZEROCONF_MDNS_SD)
        mDNSProcess();
		// Use this function to exercise service update function
		// HTTPUpdateRecord();
        #endif


		// timeout mangement for RX data stream, do not load the interrupt routine
		if (rxflag)
			{
			startTime = TickGet();		// start timeout
			rxflag = FALSE;				// reset for next cycle
			}

   		__asm__ ("clrwdt");  // watxhdog refresh set a 16"

		// timeout if not connected
		if (wstat != 1)		// connected ?
			{
			// check for timeout connection 
			if((TickGet() - timeoutconnection) > TICK_MINUTE * 5)
				{
				SetLogicalConnectionState(FALSE);
    			__asm__ ("goto 0x0000");  // riparti !!!   				
				StackInit();
				WF_Connect();
				timeoutconnection = TickGet();		// refresh
				}
			}
		else
			timeoutconnection = TickGet();		// refresh


		// Process application specific tasks here.
		DanfossMNG(); // Dangoss inverter management, main application flow


		#if defined(STACK_USE_GENERIC_TCP_CLIENT_EXAMPLE)
		GenericTCPClient();
		#endif
		
		#if defined(STACK_USE_GENERIC_TCP_SERVER_EXAMPLE)
		GenericTCPServer();
		#endif
		

        #if defined(WF_CONSOLE)
		WFConsoleProcess();
		IperfAppCall();
		WFConsoleProcessEpilogue();
		#endif



        // If the local IP address has changed (ex: due to DHCP lease change)
        // write the new IP address to the LCD display, UART, and Announce 
        // service
		if(dwLastIP != AppConfig.MyIPAddr.Val)
		{
			dwLastIP = AppConfig.MyIPAddr.Val;
			
			#if defined(STACK_USE_UART)
				putrsUART((ROM char*)"\r\nNew IP Address: ");
			#endif

			DisplayIPValue(AppConfig.MyIPAddr);

			#if defined(STACK_USE_UART)
				putrsUART((ROM char*)"\r\n");
			#endif


			#if defined(STACK_USE_ANNOUNCE)
				AnnounceIP();
			#endif

            #if defined(STACK_USE_ZEROCONF_MDNS_SD)
				mDNSFillHostRecord();
			#endif
		}
		
	}
}


/****************************************************************************
  SECTION 	Functions
****************************************************************************/

#if defined(WF_CS_TRIS)
/*****************************************************************************
 FUNCTION 	WF_Connect
			::Customize as needed for your application::
 
 RETURNS  	None
 
 PARAMS		None
*****************************************************************************/
static void WF_Connect(void)
{
    
    UINT8 channelList[] = MY_DEFAULT_CHANNEL_LIST;
    #if defined(WF_USE_POWER_SAVE_FUNCTIONS)
    BOOL  PsPollEnabled;
    #endif

	Conn_stat=1;

    /* create a Connection Profile */
    if (ConnectionProfileID==0)
		WF_CPCreate(&ConnectionProfileID);

    WF_CPSetSsid(ConnectionProfileID, 
                 AppConfig.MySSID, 
                 AppConfig.SsidLength);

    WF_CPSetNetworkType(ConnectionProfileID, MY_DEFAULT_NETWORK_TYPE);   
    WF_CASetScanType(MY_DEFAULT_SCAN_TYPE);
    WF_CASetChannelList(channelList, sizeof(channelList));
    WF_CASetListRetryCount(MY_DEFAULT_LIST_RETRY_COUNT);
    WF_CASetEventNotificationAction(MY_DEFAULT_EVENT_NOTIFICATION_LIST);
    
#if defined(WF_USE_POWER_SAVE_FUNCTIONS)
    PsPollEnabled = (MY_DEFAULT_PS_POLL == WF_ENABLED);
    if (!PsPollEnabled)
    {    
        /* disable low power (PS-Poll) mode */
        #if defined(STACK_USE_UART)
        putrsUART("Disable PS-Poll\r\n");        
        #endif
        WF_PsPollDisable();
    }    
    else
    {
        /* Enable low power (PS-Poll) mode */
        #if defined(STACK_USE_UART)
        putrsUART("Enable PS-Poll\r\n");        
        #endif
        WF_PsPollEnable(TRUE);
    }    
#endif
    WF_CASetBeaconTimeout(40);
    
    /* Set Security */
    WF_CPSetSecurity(ConnectionProfileID,
                     AppConfig.SecurityMode,
                     AppConfig.WepKeyIndex,   /* only used if WEP enabled */
                     AppConfig.SecurityKey,
                     AppConfig.SecurityKeyLength);
    #if defined(STACK_USE_UART)                     
    putrsUART("Start WiFi Connect\r\n");        
    #endif

    WF_CMConnect(ConnectionProfileID);
}   
#endif /* WF_CS_TRIS */

// Writes an IP address to the UART as available
void DisplayIPValue(IP_ADDR IPVal)
{

    BYTE IPDigit[4];
	BYTE i;

	for(i = 0; i < sizeof(IP_ADDR); i++)
	{
	    uitoa((WORD)IPVal.v[i], IPDigit);

		#if defined(STACK_USE_UART)
			putsUART((char *) IPDigit);
		#endif


		if(i == sizeof(IP_ADDR)-1)
			break;

		#if defined(STACK_USE_UART)
			while(BusyUART());
			WriteUART('.');
		#endif
	}

}




/****************************************************************************
  Function 		static void InitializeBoard(void)

  Description 	This routine initializes the hardware.

  Precondition	None

  Parameters    None - None

  Returns	    None

  Remarks 		None
 ****************************************************************************/
static void InitializeBoard(void)
{	
	// LEDs
	LED0_TRIS = 0;
	LED1_TRIS = 0;
	LED2_TRIS = 0;
	LED3_TRIS = 0;
	LED4_TRIS = 0;
	
	// Digital IN Pull Ups
	BUTTON0_PU = 1;
	BUTTON1_PU = 1;
	BUTTON2_PU = 1;
	BUTTON3_PU = 1;
	BUTTON4_PU = 1;
	
	// Initializing  ADC
	AD1CON1 = 0x00E4;	 //ADC on, auto sample, result like integer
	AD1PCFGL=0xFF;
	AD1PCFGH=0x3;
	AD1CON2bits.VCFG0=0;
	AD1CON2bits.VCFG1=0;
	AD1CON2bits.VCFG2=0;
	AD1CON2bits.CSCNA=1;
	AD1CON2bits.BUFM=0;
	AD1CON2bits.ALTS=0;
	AD1CON2bits.SMPI0=1;
	AD1CON2bits.SMPI1=0;
	AD1CON2bits.SMPI2=0;
	AD1CON2bits.SMPI3=0;
	

	//AD1CON2 = 0x6000;	 			//Vref+, Vref-, valore come int
	AD1CON3 = 0x1F05;	 			// auto-sample, Tad = 5*Tcy
	AD1CHS = 0xE;	
	AD1PCFGbits.PCFG14 = 0;	 		// AN14 - digital output disabled
	AD1PCFGbits.PCFG15 = 0;	 		// AN14 - digital output disabled
	AD1CSSL = 0xC000;	
	AD1CHS = 0xE; 
	AD1CON1 = 0x80E4;



	CLKDIVbits.RCDIV = 0;			// Set 1:1 8MHz FRC postscalar

	RCONbits.SWDTEN = 1;			// enable wdog
	

// UART
		UARTTX_TRIS = 0;
		UARTRX_TRIS = 1;
		UMODE = 0x8000;				// Set UARTEN.  Note: this must be done before setting UTXEN
		USTA = 0x0400;				// UTXEN set
		IEC1bits.U2RXIE = 1;
		#define CLOSEST_UBRG_VALUE ((GetPeripheralClock()+8ul*BAUD_RATE)/16/BAUD_RATE-1)
		#define BAUD_ACTUAL (GetPeripheralClock()/16/(CLOSEST_UBRG_VALUE+1))
	
	
		#define BAUD_ERROR ((BAUD_ACTUAL > BAUD_RATE) ? BAUD_ACTUAL-BAUD_RATE : BAUD_RATE-BAUD_ACTUAL)
		#define BAUD_ERROR_PRECENT	((BAUD_ERROR*100+BAUD_RATE/2)/BAUD_RATE)
		#if (BAUD_ERROR_PRECENT > 3)
			#warning UART frequency error is worse than 3%
		#elif (BAUD_ERROR_PRECENT > 2)
			#warning UART frequency error is worse than 2%
		#endif
	
		UBRG = CLOSEST_UBRG_VALUE;


#if defined(WF_CS_TRIS)
	WF_CS_IO = 1;
	WF_CS_TRIS = 0;
#endif

/****************************************************************************
  SECTION 	PPS (Peripheral Pin Select)
****************************************************************************/
__builtin_write_OSCCONL(OSCCON & 0xBF);				// Unlock registers

// Configure SPI1 PPS pins 
RPOR10bits.RP21R = 8;					// Assign RP21 to SCK1 (output)
RPOR13bits.RP26R = 7;					// Assign RP26 to SDO1 (output)
RPINR20bits.SDI1R = 19;					// Assign RP23 to SDI1 (input)

// Configure UART 2 pins
RPINR19bits.U2RXR = 24;					// Assign RP24 to U2RX (input)
RPOR11bits.RP22R = 5;					// Assign RP22 to U2TX (output)

// Configure INT1 PPS pin 
RPINR0bits.INT1R = 13;					// Assign RP13 to INT1 (input)

}

/*********************************************************************
  Function	        void InitAppConfig(void)
 
  PreCondition	    MPFSInit() is already called.
  
  Input	          	None
 
  Output	        Write/Read non-volatile config variables.

  Side Effects      None
 
  Overview	        None
 
  Note              None
 ********************************************************************/
// MAC Address Serialization using a MPLAB PM3 Programmer and 
// Serialized Quick Turn Programming (SQTP). 
// The advantage of using SQTP for programming the MAC Address is it
// allows you to auto-increment the MAC address without recompiling 
// the code for each unit.  To use SQTP, the MAC address must be fixed
// at a specific location in program memory.  Uncomment these two pragmas
// that locate the MAC address at 0x1FFF0.  Syntax below is for MPLAB C 
// Compiler for PIC18 MCUs. Syntax will vary for other compilers.

//#pragma romdata MACROM=0x1FFF0
static ROM BYTE SerializedMACAddress[6] = {MY_DEFAULT_MAC_BYTE1, MY_DEFAULT_MAC_BYTE2, MY_DEFAULT_MAC_BYTE3, MY_DEFAULT_MAC_BYTE4, MY_DEFAULT_MAC_BYTE5, MY_DEFAULT_MAC_BYTE6};
//#pragma romdata

static void InitAppConfig(void)
{
	AppConfig.Flags.bIsDHCPEnabled = TRUE;
	AppConfig.Flags.bInConfigMode = TRUE;
	memcpypgm2ram((void*)&AppConfig.MyMACAddr, (ROM void*)SerializedMACAddress, sizeof(AppConfig.MyMACAddr));
//	{
//		_prog_addressT MACAddressAddress;
//		MACAddressAddress.next = 0x157F8;
//		_memcpy_p2d24((char*)&AppConfig.MyMACAddr, MACAddressAddress, sizeof(AppConfig.MyMACAddr));
//	}
	AppConfig.MyIPAddr.Val = MY_DEFAULT_IP_ADDR_BYTE1 | MY_DEFAULT_IP_ADDR_BYTE2<<8ul | MY_DEFAULT_IP_ADDR_BYTE3<<16ul | MY_DEFAULT_IP_ADDR_BYTE4<<24ul;
	AppConfig.DefaultIPAddr.Val = AppConfig.MyIPAddr.Val;
	AppConfig.MyMask.Val = MY_DEFAULT_MASK_BYTE1 | MY_DEFAULT_MASK_BYTE2<<8ul | MY_DEFAULT_MASK_BYTE3<<16ul | MY_DEFAULT_MASK_BYTE4<<24ul;
	AppConfig.DefaultMask.Val = AppConfig.MyMask.Val;
	AppConfig.MyGateway.Val = MY_DEFAULT_GATE_BYTE1 | MY_DEFAULT_GATE_BYTE2<<8ul | MY_DEFAULT_GATE_BYTE3<<16ul | MY_DEFAULT_GATE_BYTE4<<24ul;
	AppConfig.PrimaryDNSServer.Val = MY_DEFAULT_PRIMARY_DNS_BYTE1 | MY_DEFAULT_PRIMARY_DNS_BYTE2<<8ul  | MY_DEFAULT_PRIMARY_DNS_BYTE3<<16ul  | MY_DEFAULT_PRIMARY_DNS_BYTE4<<24ul;
	AppConfig.SecondaryDNSServer.Val = MY_DEFAULT_SECONDARY_DNS_BYTE1 | MY_DEFAULT_SECONDARY_DNS_BYTE2<<8ul  | MY_DEFAULT_SECONDARY_DNS_BYTE3<<16ul  | MY_DEFAULT_SECONDARY_DNS_BYTE4<<24ul;
	

	// SNMP Community String configuration
	#if defined(STACK_USE_SNMP_SERVER)
	{
		BYTE i;
		static ROM char * ROM cReadCommunities[] = SNMP_READ_COMMUNITIES;
		static ROM char * ROM cWriteCommunities[] = SNMP_WRITE_COMMUNITIES;
		ROM char * strCommunity;
		
		for(i = 0; i < SNMP_MAX_COMMUNITY_SUPPORT; i++)
		{
			// Get a pointer to the next community string
			strCommunity = cReadCommunities[i];
			if(i >= sizeof(cReadCommunities)/sizeof(cReadCommunities[0]))
				strCommunity = "";

			// Ensure we don't buffer overflow.  If your code gets stuck here, 
			// it means your SNMP_COMMUNITY_MAX_LEN definition in TCPIPConfig.h 
			// is either too small or one of your community string lengths 
			// (SNMP_READ_COMMUNITIES) are too large.  Fix either.
			if(strlenpgm(strCommunity) >= sizeof(AppConfig.readCommunity[0]))
				while(1);
			
			// Copy string into AppConfig
			strcpypgm2ram((char*)AppConfig.readCommunity[i], strCommunity);

			// Get a pointer to the next community string
			strCommunity = cWriteCommunities[i];
			if(i >= sizeof(cWriteCommunities)/sizeof(cWriteCommunities[0]))
				strCommunity = "";

			// Ensure we don't buffer overflow.  If your code gets stuck here, 
			// it means your SNMP_COMMUNITY_MAX_LEN definition in TCPIPConfig.h 
			// is either too small or one of your community string lengths 
			// (SNMP_WRITE_COMMUNITIES) are too large.  Fix either.
			if(strlenpgm(strCommunity) >= sizeof(AppConfig.writeCommunity[0]))
				while(1);

			// Copy string into AppConfig
			strcpypgm2ram((char*)AppConfig.writeCommunity[i], strCommunity);
		}
	}
	#endif

	// Load the default NetBIOS Host Name
	memcpypgm2ram(AppConfig.NetBIOSName, (ROM void*)MY_DEFAULT_HOST_NAME, 16);
	FormatNetBIOSName(AppConfig.NetBIOSName);

	#if defined(WF_CS_TRIS)
		// Load the default SSID Name
		WF_ASSERT(sizeof(MY_DEFAULT_SSID_NAME) <= sizeof(AppConfig.MySSID));
		memcpypgm2ram(AppConfig.MySSID, (ROM void*)MY_DEFAULT_SSID_NAME, sizeof(MY_DEFAULT_SSID_NAME));
		AppConfig.SsidLength = sizeof(MY_DEFAULT_SSID_NAME) - 1;

        AppConfig.SecurityMode = MY_DEFAULT_WIFI_SECURITY_MODE;
        AppConfig.WepKeyIndex  = MY_DEFAULT_WEP_KEY_INDEX;
//AppConfig.dataValid=1;
//AppConfig.saveSecurityInfo=1; 
        
        #if (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_OPEN)
            memset(AppConfig.SecurityKey, 0x00, sizeof(AppConfig.SecurityKey));
            AppConfig.SecurityKeyLength = 0;

        #elif MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WEP_40
            memcpypgm2ram(AppConfig.SecurityKey, (ROM void*)MY_DEFAULT_WEP_KEYS_40, sizeof(MY_DEFAULT_WEP_KEYS_40) - 1);
            AppConfig.SecurityKeyLength = sizeof(MY_DEFAULT_WEP_KEYS_40) - 1;

        #elif MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WEP_104
		    memcpypgm2ram(AppConfig.SecurityKey, (ROM void*)MY_DEFAULT_WEP_KEYS_104, sizeof(MY_DEFAULT_WEP_KEYS_104) - 1);
		    AppConfig.SecurityKeyLength = sizeof(MY_DEFAULT_WEP_KEYS_104) - 1;

        #elif (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WPA_WITH_KEY)       || \
              (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WPA2_WITH_KEY)      || \
              (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WPA_AUTO_WITH_KEY)
		    memcpypgm2ram(AppConfig.SecurityKey, (ROM void*)MY_DEFAULT_PSK, sizeof(MY_DEFAULT_PSK) - 1);
		    AppConfig.SecurityKeyLength = sizeof(MY_DEFAULT_PSK) - 1;

        #elif (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WPA_WITH_PASS_PHRASE)     || \
              (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WPA2_WITH_PASS_PHRASE)    || \
              (MY_DEFAULT_WIFI_SECURITY_MODE == WF_SECURITY_WPA_AUTO_WITH_PASS_PHRASE)
            memcpypgm2ram(AppConfig.SecurityKey, (ROM void*)MY_DEFAULT_PSK_PHRASE, sizeof(MY_DEFAULT_PSK_PHRASE) - 1);
            AppConfig.SecurityKeyLength = sizeof(MY_DEFAULT_PSK_PHRASE) - 1;

        #else 
            #error "No security defined"
        #endif /* MY_DEFAULT_WIFI_SECURITY_MODE */

	#endif
}

/*

# >5.20 stack 
# once every sixty seconds or so 
   if((MACIsLinked()==FALSE))
{
  #  not connected");
           WF_CMConnect(1);
    
   } else {
   scanready=FALSE;  // I use these to ensure that I do not scan when there is a scan active
   WF_Scan(1); // you can then get the rssi strength when this completes
   } 
*/
