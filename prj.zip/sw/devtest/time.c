// time.c

/************************************************************************
* Software License Agreement
*
* source Maxim appnotes 517
*
* adjusted by Roberto Buti 09/04/2011
************************************************************************/
#include "TCPIP Stack/Tick.h"
#include "TCPIP Stack/helpers.h"


void UTCToDate(unsigned char format,char String[]);
unsigned long binary;


 
// this array represents the number of days in one non-leap year at 
//    the beginning of each month
unsigned long DaysToMonth[13] = {
   0,31,59,90,120,151,181,212,243,273,304,334,365
};

//***********************************************************************************
//
#define localtime 1		// central europe = UTC + 1 change for other location
//
//***********************************************************************************

void UTCToDate(unsigned char format,char String[])
 {   
   unsigned long whole_minutes;
   unsigned long whole_hours;
   unsigned long whole_days;
   unsigned long whole_days_since_1968;
   unsigned long leap_year_periods;
   unsigned long days_since_current_lyear;
   unsigned long whole_years;
   unsigned long days_since_first_of_year;
   unsigned long days_to_month;

	unsigned char hour;
	unsigned char day;
	unsigned char minute;
	unsigned char month;
	unsigned char year;
	char *pnt;
	char strbuffer[20];

   //unsigned long day_of_week;
	binary = SNTPGetUTCSeconds();	// get current UTC

	binary = binary + 3600 * localtime;	// correct for local time
	whole_minutes = binary / 60;
//   second = binary - (60 * whole_minutes);                 // leftover seconds

   whole_hours  = whole_minutes / 60;
   minute = whole_minutes - (60 * whole_hours);            // leftover minutes

   whole_days   = whole_hours / 24;
   hour         = whole_hours - (24 * whole_days);         // leftover hours
        
   whole_days_since_1968 = whole_days + 365 + 366;
   leap_year_periods = whole_days_since_1968 / ((4 * 365) + 1);

   days_since_current_lyear = whole_days_since_1968 % ((4 * 365) + 1);
        
   // if days are after a current leap year then add a leap year period
   if ((days_since_current_lyear >= (31 + 29))) {
      leap_year_periods++;
   }
   whole_years = (whole_days_since_1968 - leap_year_periods) / 365;
   days_since_first_of_year = whole_days_since_1968 - (whole_years * 365) - leap_year_periods;

   if ((days_since_current_lyear <= 365) && (days_since_current_lyear >= 60)) {
      days_since_first_of_year++;
   }
   year = whole_years + 68 - 100; 	// year based from 2000.

   // setup for a search for what month it is based on how many days have past
   //   within the current year
   month = 13;
   days_to_month = 366;
   while (days_since_first_of_year < days_to_month) {
       month--;
       days_to_month = DaysToMonth[month-1];
       if ((month > 2) && ((year % 4) == 0)) {
           days_to_month++;
        }
   }
   day = days_since_first_of_year - days_to_month + 1;
//   day_of_week = (whole_days  + 4) % 7;

//   datetime->tm_yday = 
//       days_since_first_of_year;      // days since January 1 - [0,365]       
//   datetime->tm_wday = day_of_week;   // days since Sunday - [0,6]            
	if (format)
		pnt = strcpy(String,"&d=20");	// initial id
	else
		pnt = strcpy(String,"20");	// initial id	
	uitoa((unsigned int)year,(unsigned char*)strbuffer);	// convert year to string we suppose <<99
	strcat(String,strbuffer);		// appen the year
	if (format == 0)
		strcat(String," ");		// append a space
	uitoa((unsigned int)month,(unsigned char*)strbuffer);	// month to string
	if (month < 10)
		strcat(String,"0");		
	strcat(String,strbuffer);
	if (format == 0)
		strcat(String," ");		// append a space
	uitoa((unsigned int)day,(unsigned char*)strbuffer);	// day to string
	if (day < 10)
		strcat(String,"0");		
	strcat(String,strbuffer);
	if (format == 0)
		strcat(String,"   ");		// append a space
	else
		strcat(String,"&t=");			// time id
	uitoa((unsigned int)hour,(unsigned char*)strbuffer);	// hour to string
	if (hour < 10)
		strcat(String,"0");		
	strcat(String,strbuffer);
	strcat(String,":");			// :
	uitoa((unsigned int)minute,(unsigned char*)strbuffer);	// minute to string
	if (minute < 10)
		strcat(String,"0");		
	strcat(String,strbuffer);
}


