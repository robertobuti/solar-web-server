
#ifndef __HARDWARE_PROFILE_H
#define __HARDWARE_PROFILE_H

#include "GenericTypeDefs.h"
#include "Compiler.h"


//-------------------------------------------------------------------------------------------
//|									--- CONFIGURATION BITS ---								|
//-------------------------------------------------------------------------------------------
	#if defined(THIS_IS_STACK_APPLICATION)
			_CONFIG2(FNOSC_PRI & POSCMOD_HS)		// Primary HS OSC 
//			_CONFIG1(JTAGEN_OFF & FWDTEN_OFF & ICS_PGx2)		// JTAG off, watchdog timer off
			_CONFIG1(JTAGEN_OFF & FWDTEN_ON & ICS_PGx2 & WDTPS_PS16384 & FWPSA_PR128)

	#endif // Prevent more than one set of config fuse definitions


//-------------------------------------------------------------------------------------------
//|									--- CLOCK FREQUENCY ---									|
//-------------------------------------------------------------------------------------------
	#define GetSystemClock()		(32000000ul)      // Hz
	#define GetInstructionClock()	(GetSystemClock()/2)
	#define GetPeripheralClock()	GetInstructionClock()


	
//-------------------------------------------------------------------------------------------
//|									--- HARDWARE MAPPING ---								|
//-------------------------------------------------------------------------------------------

//	Output config
	#define LED0_TRIS			(TRISFbits.TRISF5)	// LED0 -> RF5
	#define LED0_IO				(LATFbits.LATF5)

	#define LED1_TRIS			(TRISFbits.TRISF2)	// LED1 -> RF2
	#define LED1_IO				(LATFbits.LATF2)

	#define LED2_TRIS			(TRISBbits.TRISB8)	// LED2 -> RB8
	#define LED2_IO				(LATBbits.LATB8)

	#define LED3_TRIS			(TRISBbits.TRISB9)	// LED3 -> RB9
	#define LED3_IO				(LATBbits.LATB9)

	#define LED4_TRIS			(TRISBbits.TRISB10)	// LED4 -> RB10
	#define LED4_IO				(LATBbits.LATB10)

	#define LED_GET()			(*((volatile unsigned char*)(&LATA)))
	#define LED_PUT(a)			(*((volatile unsigned char*)(&LATA)) = (a))
	
//	Input config	
	#define BUTTON0_TRIS		(TRISFbits.TRISF3)	// IN0 -> RF3
	#define	BUTTON0_IO			(PORTFbits.RF3)
	#define BUTTON0_PU			(CNPU5bits.CN71PUE)


	#define BUTTON1_TRIS		(TRISFbits.TRISF6)	// IN1 -> RF6
	#define	BUTTON1_IO			(PORTFbits.RF6)
	#define BUTTON1_PU			(CNPU5bits.CN72PUE)

	#define BUTTON2_TRIS		(TRISDbits.TRISD9)	// IN2 -> RD9
	#define	BUTTON2_IO			(PORTDbits.RD9)
	#define BUTTON2_PU			(CNPU4bits.CN54PUE)
	
	#define BUTTON3_TRIS		(TRISDbits.TRISD11)	// IN3 -> RD11
	#define	BUTTON3_IO			(PORTDbits.RD11)
	#define BUTTON3_PU			(CNPU4bits.CN56PUE)
	
	#define BUTTON4_TRIS		(TRISFbits.TRISF4)	// IN4 -> RF4
	#define	BUTTON4_IO			(PORTFbits.RF4)
	#define BUTTON4_PU			(CNPU2bits.CN17PUE)

//	UART2 config
	#define UARTTX_TRIS			(TRISDbits.TRISD5)
	#define UARTTX_IO			(PORTDbits.RD5)
	#define UARTRX_TRIS			(TRISDbits.TRISD1)
	#define UARTRX_IO			(PORTDbits.RD1)


//-------------------------------------------------------------------------------------------
//|									--- WIFI MODULE MAPPING ---								|
//-------------------------------------------------------------------------------------------
	#define MRF24WB0M_IN_SPI1
	
	#define WF_CS_TRIS			(TRISGbits.TRISG9)
	#define WF_CS_IO			(LATGbits.LATG9)
	#define WF_SDI_TRIS			(TRISGbits.TRISG7)
	#define WF_SCK_TRIS			(TRISGbits.TRISG6)
	#define WF_SDO_TRIS			(TRISGbits.TRISG8)
	#define WF_RESET_TRIS		(TRISEbits.TRISE7)
	#define WF_RESET_IO			(LATEbits.LATE7)
	#define WF_INT_TRIS	    	(TRISBbits.TRISB2)  // INT1
	#define WF_INT_IO			(PORTBbits.RB2)
	#define WF_HIBERNATE_TRIS	(TRISEbits.TRISE6)
	#define	WF_HIBERNATE_IO		(PORTEbits.RE6)
	#define WF_INT_EDGE		    (INTCON2bits.INT1EP)
	#define WF_INT_IE			(IEC1bits.INT1IE)
	#define WF_INT_IF			(IFS1bits.INT1IF)
	
	#define WF_SSPBUF			(SPI1BUF)
	#define WF_SPISTAT			(SPI1STAT)
	#define WF_SPISTATbits		(SPI1STATbits)
	#define WF_SPICON1			(SPI1CON1)
	#define WF_SPICON1bits		(SPI1CON1bits)
	#define WF_SPICON2			(SPI1CON2)
	#define WF_SPI_IE			(IEC0bits.SPI1IE)
	//#define WF_SPI_IP			(IPC2bits.SPI1IP)
	#define WF_SPI_IF			(IFS0bits.SPI1IF)




//-------------------------------------------------------------------------------------------
//|										--- UART DEFINE ---									|
//-------------------------------------------------------------------------------------------

	#define UBRG					U2BRG
	#define UMODE					U2MODE
	#define USTA					U2STA
	#define BusyUART()				BusyUART2()
	#define CloseUART()				CloseUART2()
	#define ConfigIntUART(a)		ConfigIntUART2(a)
	#define DataRdyUART()			DataRdyUART2()
	#define OpenUART(a,b,c)			OpenUART2(a,b,c)
	#define ReadUART()				ReadUART2()
	#define WriteUART(a)			WriteUART2(a)
	#define getsUART(a,b,c)			getsUART2(a,b,c)
	#define putsUART(a)			putsUART2((unsigned int*)a)
	#define getcUART()				getcUART2()
	#define putcUART(a)				do{while(BusyUART()); WriteUART(a); while(BusyUART()); }while(0)
	#define putrsUART(a)			putrsUART2(a)
#endif
