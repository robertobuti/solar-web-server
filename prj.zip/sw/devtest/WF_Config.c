/* **************************************************************************																					
 *                                OpenPicus                 www.openpicus.com
 *                                                            italian concept
 * 
 *            openSource wireless Platform for sensors and Internet of Things	
 * **************************************************************************
 *  FileName:        HTTPApp.c
 *  Dependencies:    TCP/IP stack
 *  Module:          FlyPort WI-FI
 *  Compiler:        Microchip C30 v3.12 or higher
 *
 *
 *  Author               Rev.    Date              Comment
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *  Gabriele Allegria    1.0     10/09/2010		   First release  (core team)
 *  
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *
 *  Software License Agreement
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *  This is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License (version 2) as published by 
 *  the Free Software Foundation AND MODIFIED BY OpenPicus team.
 *  
 *  ***NOTE*** The exception to the GPL is included to allow you to distribute
 *  a combined work that includes OpenPicus code without being obliged to 
 *  provide the source code for proprietary components outside of the OpenPicus
 *  code. 
 *  OpenPicus software is distributed in the hope that it will be useful, but 
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 *  more details. 
 * 
 * 
 * Warranty
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * WE ARE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 **************************************************************************/
 
 
/****************************************************************************
  SECTION 	Include
****************************************************************************/
#include "HardwareProfile.h"

#if defined(WF_CS_TRIS)

#include "TCPIP Stack/TCPIP.h"

#if defined ( EZ_CONFIG_SCAN )
#include "TCPIP Stack/WFEasyConfig.h"
#endif /* EZ_CONFIG_SCAN */


/****************************************************************************
  SECTION	Define
****************************************************************************/

/* used for assertions */
#ifdef WF_DEBUG
    #define WF_MODULE_NUMBER    WF_MODULE_WF_CONFIG
#endif


 char wstat;
/*****************************************************************************
  FUNCTION   WF_ProcessEvent    
             :: Customize this function as needed for your application ::
 
  RETURNS    None
 
  PARAMS     event      -- event that occurred
             eventInfo  -- additional information about the event.  Not all 
   						  events have associated info, in which case this value 
						  will be set to WF_NO_ADDITIONAL_INFO (0xff)

  NOTES      The Host application must NOT directly call this function.  This 
             function is called by the WiFi Driver code when an event occurs
             that may need processing by the Host CPU.  
 
             No other WiFi Driver function should be called from this function, 
             with the exception WF_ASSERT.  It is recommended that if the 
			 application wishes to be notified of an event that it simply set a 
			 flag and let application code in the main loop handle the event. 

			 WFSetFuncState must be called when entering and leaving this 
			 function. When WF_ASSERT is enabled this allows a runtime check if 
			 any illegal WF functions are called from within this function.

			For events that the application is not interested in simply leave 
			the case statement empty.
            
 *****************************************************************************/
void WF_ProcessEvent(UINT8 event, UINT16 eventInfo)
{
    #if defined(STACK_USE_UART)
    char buf[8];
    #endif
  
    /* this function tells the WF driver that we are in this function */
    WFSetFuncState(WF_PROCESS_EVENT_FUNC, WF_ENTERING_FUNCTION);
      

			
    switch (event)
    {
        /*--------------------------------------*/
        case WF_EVENT_CONNECTION_SUCCESSFUL:
        /*--------------------------------------*/   
			LED3_IO=1;
            #if defined(STACK_USE_UART)
            putrsUART("Event: Connection Successful\r\n"); 
			Conn_stat=2;	
            #if defined(EZ_CONFIG_STORE)
                AppConfig.saveSecurityInfo = TRUE;
            #endif			
            #endif
			wstat = event;
            break;
        
        /*--------------------------------------*/            
        case WF_EVENT_CONNECTION_FAILED:
        /*--------------------------------------*/
            /* eventInfo will contain value from tWFConnectionFailureReasons */
            #if defined(STACK_USE_UART)
            putrsUART("Event: Connection Failed  -- eventInfo = ");
            sprintf(buf, "%d\r\n", eventInfo);
            putsUART(buf);
			Conn_stat=0;	
            #endif
			LED3_IO=0;
			wstat = event;
            break; 
            
        /*--------------------------------------*/
        case WF_EVENT_CONNECTION_TEMPORARILY_LOST:
        /*--------------------------------------*/
            #if defined(STACK_USE_UART)
            putrsUART("Event: Connection Temporarily Lost -- eventInfo = ");
            sprintf(buf, "%d\r\n", eventInfo);
            putsUART(buf);
            #endif
			LED3_IO=0;
			wstat = event;
            break;
            
        /*--------------------------------------*/
        case WF_EVENT_CONNECTION_PERMANENTLY_LOST:            
        /*--------------------------------------*/ 
            #if defined(STACK_USE_UART)       
            putrsUART("Event: Connection Permanently Lost -- eventInfo = ");
            sprintf(buf, "%d\r\n", eventInfo);
            putsUART(buf);
			Conn_stat=0;	
            #endif
			LED3_IO=0;
			wstat = event;
            break;
            
        /*--------------------------------------*/    
        case WF_EVENT_CONNECTION_REESTABLISHED:
        /*--------------------------------------*/
            #if defined(STACK_USE_UART)
            putrsUART("Event: Connection Reestablished\r\n");
            #endif
			LED3_IO=1;
			wstat = event;
            break;
            
        /*--------------------------------------*/    
        case WF_EVENT_SCAN_RESULTS_READY:
        /*--------------------------------------*/  
            #if defined(STACK_USE_UART)
            putrsUART("Event: Scan Results Ready,");
            sprintf(buf, "%d", eventInfo);
            putsUART(buf);
            putrsUART("results\r\n");
            #endif
            #if defined ( EZ_CONFIG_SCAN )
            WFScanEventHandler(eventInfo);
			#endif /* EZ_CONFIG_SCAN */
            break;

        /*--------------------------------------*/                            
        case WF_EVENT_RX_PACKET_RECEIVED:
        /*--------------------------------------*/                        
            #if defined(STACK_USE_UART)
//            putrsUART("Event: Rx Packet Received - length = ");
//            sprintf(buf, "%d\r\n", eventInfo);
//          putsUART(buf);
			#endif
            break;
            

        default:
            WF_ASSERT(FALSE);  /* unknown event */
            break;
    }        
    
    /* Informs the WF driver that we are leaving this function */
    WFSetFuncState(WF_PROCESS_EVENT_FUNC, WF_LEAVING_FUNCTION);
}    
  


/*****************************************************************************
  EVENT   WF_AssertionFailed()  
		  :: Customize this function as desired to handle assertion errors ::
  
  Description	Called by a WiFi library function when an assert occurs.
  
  Argument(s) 	moduleNumber - module number (located in WFApi.h)               
				lineNumber   - line number within module where assert occurred.

  Return(s)    	None

  Caller(s)  	WF Driver

  Notes	   		(1) If the WF_ASSERT macro is enabled (via the WF_DEBUG define in 
					WF_Config.h) this is the function that gets called when 
					WF_ASSERT() fails.

******************************************************************************/
#ifdef WF_DEBUG
#define WIFI_ASSERT_STRING "WiFi Assert     M:"
void WF_AssertionFailed(UINT8 moduleNumber, UINT16 lineNumber) 
{
    #if defined(STACK_USE_UART)
    char buf[8];
    
    putrsUART("WF ASSERTION: Module Number = ");
    
    sprintf(buf, "%d  ", moduleNumber);
    putsUART(buf);
    
    putrsUART("Line Number = ");
    
    sprintf(buf, "%d", lineNumber);
    putsUART(buf);
    #endif
    
 	LED3_IO=0;

    __asm__ ("goto 0x0000");  // riparti !!!

    while(1);
}    
#endif /* WF_DEBUG */

#endif /* WF_CS_TRIS */

