/* **************************************************************************																					
 *                                OpenPicus                 www.openpicus.com
 *                                                            italian concept
 * 
 *            openSource wireless Platform for sensors and Internet of Things	
 * **************************************************************************
 *  FileName:        HTTPApp.c
 *  Dependencies:    TCP/IP stack
 *  Module:          FlyPort WI-FI
 *  Compiler:        Microchip C30 v3.12 or higher
 *
 *
 *  Author               Rev.    Date              Comment
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *  Gabriele Allegria    1.0     10/09/2010		   First release  (core team)
 *  
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *
 *  Software License Agreement
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *  This is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License (version 2) as published by 
 *  the Free Software Foundation AND MODIFIED BY OpenPicus team.
 *  
 *  ***NOTE*** The exception to the GPL is included to allow you to distribute
 *  a combined work that includes OpenPicus code without being obliged to 
 *  provide the source code for proprietary components outside of the OpenPicus
 *  code. 
 *  OpenPicus software is distributed in the hope that it will be useful, but 
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 *  more details. 
 * 
 * 
 * Warranty
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * WE ARE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 **************************************************************************/
 
 
/****************************************************************************
  SECTION 	Include
****************************************************************************/
#include "TCPIPConfig.h"
#include "stdlib.h"

#if defined(STACK_USE_HTTP2_SERVER)

#include "TCPIP Stack/TCPIP.h"



/****************************************************************************
  SECTION	Define
****************************************************************************/
#define __HTTPAPP_C

extern unsigned long total_power[3];		// total power up today
extern unsigned long today_power[3];		// total power of today
extern unsigned long instant_power[3];		// instant power 

extern void UTCToDate(unsigned char);
extern char MyString[30];

/****************************************************************************
  SECTION 	Authorization Handlers
****************************************************************************/
 

/*****************************************************************************
  FUNCTION	BYTE HTTPNeedsAuth(BYTE* cFile)

  This function is used by the stack to decide if a page is access protected.
  If the function returns 0x00, the page is protected, if returns 0x80, no 
  authentication is required
*****************************************************************************/
#if defined(HTTP_USE_AUTHENTICATION)
BYTE HTTPNeedsAuth(BYTE* cFile)
{
	//	If you want to restrict the access to some page, include it in the folder "protect"
	//	here you can change the folder, or add others
	if(memcmppgm2ram(cFile, (ROM void*)"protect", 7) == 0)
		return 0x00;		// Authentication will be needed later


	// You can match additional strings here to password protect other files.
	// You could switch this and exclude files from authentication.
	// You could also always return 0x00 to require auth for all files.
	// You can return different values (0x00 to 0x79) to track "realms" for below.

	return 0x80;			// No authentication required
}
#endif

/*****************************************************************************
  FUNCTION	BYTE HTTPCheckAuth(BYTE* cUser, BYTE* cPass)
	
  This function checks if username and password inserted are acceptable

  ***************************************************************************/
#if defined(HTTP_USE_AUTHENTICATION)
BYTE HTTPCheckAuth(BYTE* cUser, BYTE* cPass)
{
	if(strcmppgm2ram((char *)cUser,(ROM char *)"admin") == 0
		&& strcmppgm2ram((char *)cPass, (ROM char *)"flyport") == 0)
		return 0x80;		// We accept this combination
	
	// You can add additional user/pass combos here.
	// If you return specific "realm" values above, you can base this 
	//   decision on what specific file or folder is being accessed.
	// You could return different values (0x80 to 0xff) to indicate 
	//   various users or groups, and base future processing decisions
	//   in HTTPExecuteGet/Post or HTTPPrint callbacks on this value.
	
	return 0x00;			// Provided user/pass is invalid
}
#endif

/****************************************************************************
  SECTION	GET Form Handlers
****************************************************************************/
  
/****************************************************************************
  FUNCTION	HTTP_IO_RESULT HTTPExecuteGet(void)
	
  This function processes every GET request from the pages. In the example, 
  it processes only the led.cgi function, but you can add code to process 
  other GET requests.
*****************************************************************************/

HTTP_IO_RESULT HTTPExecuteGet(void)
{
	CHAR *ptr;
	INT value;
	BYTE filename[20];
	 char buf[8];
	
	// Load the file name
	// Make sure BYTE filename[] above is large enough for your longest name
	MPFSGetFilename(curHTTP.file, filename, 20);

	// If it's the LED updater file
	if(!memcmppgm2ram(filename, "leds.cgi", 8))
	{
		// Determine which LED to toggle
		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"val1");
		value = atoi(ptr);
		// Toggle the specified LED
		UARTWrite(1,"Event: val1="); 
/*		sprintf(buf, "%d\r\n",ptr);
	    UARTWrite(1,buf);	
		if (*ptr < 128)
		  IOPut(o1,toggle);
			//   LIN_send_command(2,100,1534);
		if (*ptr > 128)
		  IOPut(o2,toggle);		
		if (*ptr > 200)
		  IOPut(o3,toggle);		  */
	}
	
	return HTTP_IO_DONE;
}



/***************************************************************************
  SECTION	Dynamic Variable Callback Functions
****************************************************************************/

/****************************************************************************
  FUNCTION	void HTTPPrint_varname(void)
	
  Internal: See documentation in the TCP/IP Stack API or HTTP2.h for details.
 ***************************************************************************/

ROM BYTE HTML_UP_ARROW[] = "up";
ROM BYTE HTML_DOWN_ARROW[] = "dn";

void HTTPPrint_pot(WORD num)
{
	BYTE String[10];
	
	switch(num)
	{
		case 0:
			ultoa(instant_power[0],(BYTE*)String);
			break;
		case 1:
			ultoa(today_power[0],(BYTE*)String);
			break;	
		case 2:
			ultoa(total_power[0],(BYTE*)String);
			break;	
		case 3:
			ultoa(instant_power[1],(BYTE*)String);
			break;
		case 4:
			ultoa(today_power[1],(BYTE*)String);
			break;
		case 5:
			ultoa(total_power[1],(BYTE*)String);
			break;
		case 6:
			ultoa(instant_power[2],(BYTE*)String);
			break;
		case 7:
			ultoa(today_power[2],(BYTE*)String);
			break;
		case 8:
			ultoa(total_power[2],(BYTE*)String);
			break;
		case 9:
			ultoa(instant_power[0]+instant_power[1],(BYTE*)String);
			break;
		case 10:
			ultoa(today_power[0]+today_power[1],(BYTE*)String);
			break;
		case 11:
			ultoa(total_power[0]+total_power[1],(BYTE*)String);
			break;
		case 12:
			UTCToDate(0);		// make the string with data				
			break;
		default:
			break;
	}
		if (case == 12)
			TCPPut(sktHTTP,(unsigned char)MyString);
		else			
   		TCPPutString(sktHTTP,String);
}

void HTTPPrint_btn(WORD num)
{
	// Determine which button
	switch(num)
	{
		case 0:
			num = IOGet(i1);
			break;
		case 1:
			num = IOGet(i2);
			break;
		case 2:
			num = IOGet(i3);
			break;
		case 3:
			num = IOGet(i4);
			break;
		case 4:
			num = IOGet(i5);
			break;
		default:
			num = 0;
	}

	// Print the output
	TCPPutROMString(sktHTTP, (num?HTML_UP_ARROW:HTML_DOWN_ARROW));
	return;
}
	
void HTTPPrint_led(WORD num)
{
	// Determine which LED
	switch(num)
	{
		case 0:
			num = IOGet(o1);
			break;
		case 1:
			num = IOGet(o2);
			break;
		case 2:
			num = IOGet(o3);
			break;
		case 3:
			num = IOGet(o4);
			break;
		case 4:
			num = IOGet(o5);
			break;
		default:
			num = 0;
	}

	// Print the output
	TCPPut(sktHTTP, (num?'1':'0'));
	return;
}


#endif
